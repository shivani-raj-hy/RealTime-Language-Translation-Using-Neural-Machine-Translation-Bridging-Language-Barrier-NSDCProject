# RealTime-Language-Translation-Using-Neural-Machine-Translation-Bridging-Language-Barrier-NSDCProject
 A multilingual translation system using the mT5 Transformer to break language barriers. Supports English, Japanese, and Chinese, with Beam Search for accuracy and GPU acceleration. Future plans: expand language support, deploy as an API/web app, and improve fluency.  📜 License: MIT
